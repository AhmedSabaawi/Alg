// int a;
// int a; /* random comment */
// int a; /* for storing width * height */
// int a = b * c;
// int a = b / c;
// int a = 55; // This is a comment / [
// public
// void doIt(int x) { System.out.println(x * 100); }
// int[] arr = new int[10];
// /* */ {
// }

int [arr = new int[10];
int b = 5; // this is a comment /
{
    a = b;
}

// if (a == b)
// {
//     a++;
// }
// if (a < (b * c))
// {
//     t = 5;
// }
// int[] b = new int[5];
// []() {} int a = 5; // init a to 5
